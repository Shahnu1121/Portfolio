function scrollToSection(sectionId){
    let section = document.getElementById(sectionId);
    section.scrollIntoView({behavior : "smooth"})
}






// document.addEventListener("DOMContentLoaded", function () {
//     let navLinks = document.querySelectorAll(".nav-link");
//     let navCollapse = document.querySelector(".navbar-collapse");

//     navLinks.forEach(function (link) {
//         link.addEventListener("click", function () {
//             navCollapse.classList.remove("show"); // Close navbar after click
//         });
//     });
// });




document.addEventListener('DOMContentLoaded', function(){

    let navLinks = document.querySelectorAll('.nav-link');
    let navCollapse = document.querySelector('.navbar-collapse');


    navLinks.forEach(function (link){
        link.addEventListener('click', function () {
            navCollapse.classList.remove("show")
        });
    });
});